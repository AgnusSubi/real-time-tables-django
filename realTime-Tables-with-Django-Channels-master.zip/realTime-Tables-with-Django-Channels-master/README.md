# realTime-Tables-with-Django-Channels

https://github.com/ServiceStack/redis-windows
